import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { PrismaService } from '../../../platform/database/prisma.service';
import { Request } from 'express';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private prisma: PrismaService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest<Request>();
    const token = this.extractTokenFromHeader(request);
    
    if (!token) {
      throw new UnauthorizedException('Authentication token missing');
    }

    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(token)) {
      throw new UnauthorizedException('Invalid or expired token');
    }

    let session;
    try {
      session = await this.prisma.session.findUnique({
        where: { token },
        include: { customer: true }
      });
    } catch {
      throw new UnauthorizedException('Invalid or expired token');
    }

    if (!session || !session.customer || !session.isValid || session.expiresAt < new Date()) {
      throw new UnauthorizedException('Invalid or expired token');
    }

    if (!session.customer.isActive) {
      throw new UnauthorizedException('Account has been deactivated');
    }

    // Attach user to request for use in controllers
    (request as any).user = session.customer;
    (request as any).sessionToken = token;

    return true;
  }

  private extractTokenFromHeader(request: Request): string | undefined {
    const [type, token] = request.headers.authorization?.split(' ') ?? [];
    return type === 'Bearer' ? token : undefined;
  }
}
